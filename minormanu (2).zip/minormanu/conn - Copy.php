
<?php

$username=$_POST["username"];
$password=$_POST["password"];

$conn=new mysqli('localhost','root','','use');

if($conn->connect_error){

die('Conneection Failed: '.$conn->connect_error);
}
else{

$stmt=$conn->prepare( "insert into details(username,password) values (?,?)");
$stmt->bind_param("ss",$username,$password);
$stmt->execute();
echo "details entered successfully...";
$stmt->close();
$conn->close();
}
?>